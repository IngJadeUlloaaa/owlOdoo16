/** @odoo-module **/

import { Login } from 'owl';

class LoginForm extends Login{
    static template = 'PrincipalLogin';
}

export default LoginForm;