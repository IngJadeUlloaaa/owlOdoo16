/** @odoo-module **/

import { Component, mount } from "@odoo/owl";
import { MyComponent } from "./MyComponent";

class OwlExample extends Component {
    static template = "form_login_module_template";

    async willStart() {
        this.root = mount(MyComponent, { target: document.getElementById('form_login_module_root') });
    }
}

odoo.define('form_login_module.owl_example', function (require) {
    const { Component, mount } = owl;

    mount(OwlExample, { target: document.body });
});
