/** @odoo-module **/

import { Component } from "@odoo/owl";

export class MyComponent extends Component {
    static template = "form_login_module.MyComponent";
}
