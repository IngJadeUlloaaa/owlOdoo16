# -*- coding: utf-8 -*-
# from odoo import http


# class UnmForm(http.Controller):
#     @http.route('/unm_form/unm_form', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/unm_form/unm_form/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('unm_form.listing', {
#             'root': '/unm_form/unm_form',
#             'objects': http.request.env['unm_form.unm_form'].search([]),
#         })

#     @http.route('/unm_form/unm_form/objects/<model("unm_form.unm_form"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('unm_form.object', {
#             'object': obj
#         })
