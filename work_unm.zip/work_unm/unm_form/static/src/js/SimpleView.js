/** @odoo-module **/

import { Component } from '@odoo/owl';
import { registry } from "@web/core/registry";

class SimpleView extends Component {
    static template = 'SimpleViewTemplate';
}

const SimpleViewAction = {
    name: 'simple_view',
    Component: SimpleView,
    props: {},
};

registry.category('actions').add('simple_view', SimpleViewAction);

export default SimpleView;
