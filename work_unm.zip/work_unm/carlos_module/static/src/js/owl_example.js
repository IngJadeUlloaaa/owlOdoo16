/** @odoo-module **/

import { registry } from '@web/core/registry';
const { Component, useState } = owl;

const API_URL_LOGIN = "https://192.168.23.248:4500/api/v1/auth/login";
const API_URL_ASIGNATURAS = "https://192.168.23.248:4500/api/v1/matricula/asignaturas/search";

// Funciones para manejar cookies
function setCookie(name, value, days) {
    let expires = "";
    if (days) {
        let date = new Date();
        date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
        expires = "; expires=" + date.toUTCString();
    }
    document.cookie = name + "=" + (value || "") + expires + "; path=/";
}

function getCookie(name) {
    let nameEQ = name + "=";
    let ca = document.cookie.split(';');
    for (let i = 0; i < ca.length; i++) {
        let c = ca[i];
        while (c.charAt(0) === ' ') c = c.substring(1, c.length);
        if (c.indexOf(nameEQ) === 0) return c.substring(nameEQ.length, c.length);
    }
    return null;
}

function eraseCookie(name) {
    document.cookie = name + '=; Max-Age=-99999999;';
}

export class OwlHome extends Component {
    setup() {
        // No es necesario hacer nada aquí en este momento
    }

    async toLogin() {
        // Redirigir al usuario usando window.location.href
        window.location.href = "/web#action=owl.action_todo_list_js";
    }
}

OwlHome.template = 'owl.Home';
registry.category('actions').add('owl.action_home', OwlHome);

export class OwlTodoList extends Component {
    setup() {
        this.token = null;
    }

    async postData() {
        let username = document.getElementById('username').value;
        let password = document.getElementById('password').value;

        if (!username || !password) {
            alert("Por favor, llene todos los campos.");
            return;
        }

        let credentials = {
            username: username,
            passwd: password
        };

        console.log("Enviando credenciales:", JSON.stringify(credentials));

        try {
            let response = await fetch(API_URL_LOGIN, {
                method: "POST",
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json"
                },
                credentials: "include", // Incluir cookies en la solicitud
                body: JSON.stringify(credentials)
            });

            console.log("Estado de la respuesta:", response.status);
            if (response.ok) {
                let data = await response.json();
                this.token = data.accessToken;

                console.log("Token recibido:", this.token);
                alert("Sesión iniciada correctamente");

                // Almacenar el token en una cookie
                setCookie('access_token', this.token, 1);

                // Redirigir al usuario usando window.location.href
                window.location.href = "/web#action=owl.action_matricula_unica";
            } else {
                alert("Credenciales incorrectas");
            }
        } catch (error) {
            console.error("Error en la solicitud:", error);
            alert("Ocurrió un error al intentar conectarse al servidor.");
        }
    }
}

OwlTodoList.template = 'owl.TodoList';
registry.category('actions').add('owl.action_todo_list_js', OwlTodoList);

export class OwlMatriculaUnica extends Component {
    setup() {
        this.token = getCookie('access_token'); // Recuperar el token de la cookie
        console.log("Token recuperado de la cookie:", this.token);

        if (!this.token) {
            alert("No se ha encontrado el token. Por favor, inicie sesión de nuevo.");
            window.location.href = "/web#action=owl.action_todo_list_js";
        }

        this.state = useState({
            get_http_data: [],
            id_btn: "",
            id_asignatura: "",
            id_grupo: ""
        });
    }

    async postData(data) {
        try {
            const response = await fetch(API_URL_ASIGNATURAS, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "authorization": `bearer ${this.token}`
                },
                body: JSON.stringify(data)
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const responseData = await response.json();
            console.log("Datos enviados y respuesta recibida:", responseData);
            alert("Registro agregado correctamente.");

            // Limpiar los campos después de agregar el registro
            this.state.id_btn = "";
            this.state.id_asignatura = "";
            this.state.id_grupo = "";

            // Actualizar la lista de datos
            await this.getData();
        } catch (error) {
            console.error("Error al agregar registro:", error);
            alert("Ocurrió un error al intentar agregar el registro.");
        }
    }

    async postHttpService() {
        const { id_btn, id_asignatura, id_grupo } = this.state;

        // Construir objeto de datos a enviar al backend
        const postData = {
            id_btn: id_btn,
            id_asignatura: id_asignatura,
            id_grupo: id_grupo
        };

        // Llamar al método para enviar datos al backend
        await this.postData(postData);
    }

    async getData() {
        try {
            const response = await fetch(API_URL_ASIGNATURAS, {
                method: "GET",
                headers: {
                    "authorization": `bearer ${this.token}`
                }
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const data = await response.json();

            console.log("Respuesta recibida:", data); // Agregar console log para la respuesta recibida

            if (data && data.length > 0) {  // Verifica que los datos no estén vacíos
                console.log("Datos recibidos:", data);
                this.state.get_http_data = data;  // Actualiza el estado con los datos recibidos
            } else {
                console.error("Respuesta vacía o incompleta:", data);
                alert("El servidor respondió con una tabla vacía o incompleta.");
            }
        } catch (error) {
            console.error("Error fetching data:", error);
            alert("Ocurrió un error al intentar obtener datos.");
        }
    }

    async mounted() {
        await this.getData();  // Llama al método para obtener datos cuando el componente se monta
    }
}

OwlMatriculaUnica.template = 'owl.MatriculaUnica';
registry.category('actions').add('owl.action_matricula_unica', OwlMatriculaUnica);